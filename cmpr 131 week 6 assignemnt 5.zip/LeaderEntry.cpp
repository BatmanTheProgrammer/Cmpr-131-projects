#include "LeaderEntry.h"
leaderEntry::leaderEntry()
{  
    gamePoints = 1;
    playerName = "not set";
 
    dateGame = "not set";
}
leaderEntry::leaderEntry(int pointsIn,string playerNameIn,  string dateTimeIn)
{
     playerName = playerNameIn;
     gamePoints = pointsIn;
     dateGame = dateTimeIn;

}
leaderEntry::~leaderEntry()
{

}
void leaderEntry::setPlayerName(string playerNameIn)
{
    playerName = playerNameIn;
}
string leaderEntry::getPlayerName()
{
    return playerName;
}
void leaderEntry::setPoints(int pointsIn)
{
    gamePoints = pointsIn;
}
int leaderEntry::getPoints()
{
    return gamePoints;
}
void leaderEntry::setDateGame(string dateTimeIn)
{
    dateGame = dateTimeIn;
}
string leaderEntry::getDateGame()
{
    return dateGame;
}
void leaderEntry::setLeaderStats(int points, string name, string date)
{
    dateGame = date;
    gamePoints = points;
    playerName = name;
}
void leaderEntry::printGamePoints()
{
   
    cout << "Date Game played is: " << dateGame << "\t";
   cout  << "Game points is : " << gamePoints << "\t ";
       cout << "Player name is: " << playerName << endl;
}

bool  leaderEntry::operator ==(const leaderEntry& b)
{
    return (gamePoints == b.gamePoints);
}
bool  leaderEntry::operator >(const leaderEntry& b)
{
    return (gamePoints > b.gamePoints);
}
bool  leaderEntry::operator <(const leaderEntry& b)
{
    return (gamePoints < b.gamePoints);
}
