#ifndef LEADER_ENTRY
#define LEADER_ENTRY

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

class leaderEntry
{
private:
    string playerName;
    int gamePoints;
    string  dateGame;

public:
    leaderEntry();
    leaderEntry(int pointsIn,string playerNameIn,  string dateTimeIn);
    ~leaderEntry();
    void setPlayerName(string playerNameIn);
    string getPlayerName();
    void setPoints( int pointsIn);
    int getPoints();
    void setLeaderStats(int, string, string);
    void setDateGame( string dateTimeIn);
    string getDateGame();
    void printGamePoints();
   
    bool  operator ==(const leaderEntry& b);
    bool  operator >(const leaderEntry& b);
    bool  operator <(const leaderEntry& b);
};
#endif // !LEADER_ENTRY

