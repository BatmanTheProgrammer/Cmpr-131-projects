// Carlos Duque
// Week 6 Assignment 5
//COURSE: CMPR 131 Section #86430


#include <iostream>
#include "LeaderEntry.h"
#include <fstream>

using namespace std;
class nodeType
{
	//leaderEntry  topTenBoard;
public:
	//int info;
	leaderEntry topTenLeaderBoard;

	nodeType* link;
	nodeType* buildListForward();
};
//nodeType* buildListForward()
//{
//	nodeType* first, * newNode, * last;
//	int num;
//	cout << "Enter a list of integers ending with -999." << endl;
//	cin >> num;
//	first = nullptr;
//  last = nullptr;
//	while (num != -999)
//	{
//		newNode = new nodeType;
//		newNode->info = num;
//		newNode->link = nullptr;
//		if (first == nullptr)
//		{
//			first = newNode;
//			last = newNode;
//		}
//		else
//		{
//			last->link = newNode;
//			last = newNode;
//		}
//		cin >> num;
//	} //endwhile
//
//	return first;
//}
int main()
{
	
	fstream inData;
	inData.open("Gamers.txt");

	nodeType* first, * newNode, * last , *current;

	first = nullptr;
	last = nullptr;
	int const MAX=10;
	string name[MAX], date[MAX];
	int points[MAX], index=0;
	inData >> name[0];
	
	while (index < MAX)
	{
		
		inData >>  points[index] >> date[index];
		newNode = new nodeType;
		newNode->topTenLeaderBoard.setLeaderStats(points[index], name[index], date[index]);
		newNode->link = nullptr;
		if (first == nullptr)
		{
			first = newNode;
			last = newNode;
			
			
		}
		else
		{
			last->link = newNode;
			last = newNode;
			
		}	
		index++;
		inData >> name[index];
	}

	current = first;

	while (current != nullptr)
	{
		current->topTenLeaderBoard.printGamePoints(); cout << endl;
		current = current->link;
	}
	return 0;
}